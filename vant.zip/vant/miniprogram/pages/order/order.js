Page({

  pfindcar: function () {

    wx.navigateTo({
      url: '../myinfo/myinfo'
    })
  },
  carfindp: function () {

    wx.navigateTo({
      url: '../carfindp/index'
    })
  },

})
