var city = [
  {
    title:"热门城市",
    type:'hot',
    item: [

      {
        "name": "New York",
        "key": "热门",
        "test":"testValue"
      },
      {
        "name": "Colorado",
        "key": "热门"
      },
      {
        "name": "Nebraska",
        "key": "热门"
      },
      {
        "name": "Alaska",
        "key": "热门"
      },
      {
        "name": "Nevada",
        "key": "热门"
      },

      {
        "name": "Arizona",
        "key": "热门"
      },
      {
        "name": "New Hampshire",
        "key": "热门"
      },
      {
        "name": "Arkansas",
        "key": "热门"
      },
      {
        "name": "New Jersy",
        "key": "热门"
      },
      {
        "name": "California",
        "key": "热门"
      },
      {
        "name": "New Mexico",
        "key": "热门"
      },

      {
        "name": "Connecticut",
        "key": "热门"
      }

    ]
  }, {
    title:"A",
    item: [
      {
        "name": "Alaska",
        "key": "A"
      },
      {
        "name": "Albany",
        "key": "A"
      },
      {
        "name": "Annapolis",
        "key": "A"
      },
      {
        "name": "Atlanta",
        "key": "A"
      },
      {
        "name": "Augusta",
        "key": "A"
      },

      {
        "name": "Austin",
        "key": "A"
      }
  
    ]
  }, {
    title: "B",
    item: [
      {
        "name": "Baton Rouge",
        "key": "B"
      },
      {
        "name": "Bismarck",
        "key": "B"
      },
      {
        "name": "Boise",
        "key": "B"
      },
      {
        "name": "Boston",
        "key": "B"
      }
    ]
  }, {
    title: "C",
    item: [
      {
        "name": "Carson City",
        "key": "C"
      },
      {
        "name": "Charleston",
        "key": "C"
      },
      {
        "name": "Cheyenne",
        "key": "C"
      },
      {
        "name": "Chicago",
        "key": "C"
      },
      {
        "name": "Cincinati",
        "key": "C"
      },
      {
        "name": "Cleveland",
        "key": "C"
      },
      {
        "name": "Columbia",
        "key": "C"
      }
      ,
      {
        "name": "Columbus",
        "key": "C"
      }
      
    ]
  }, {
    title: "D",
    item: [
      {
        "name": "Dallas",
        "key": "D"
      },
      {
        "name": "Denver",
        "key": "D"
      },
      {
        "name": "Des Moines",
        "key": "D"
      },
      {
        "name": "Detroit",
        "key": "D"
      },
      {
        "name": "Dover",
        "key": "D"
      }
    ]
  }, {
    title: "F",
    item: [
      {
        "name": "Frankfort",
        "key": "F"
      }
    
    ]
  }, {

    title: "H",
    item: [
      {
        "name": "Harrisburg",
        "key": "H"
      },
      {
        "name": "Hartford",
        "key": "H"
      },
      {
        "name": "Hawaii",
        "key": "H"
      },
      {
        "name": "Helena",
        "key": "H"
      },
      {
        "name": "Houston",
        "key": "H"
      }

    ]
  }, {
    title: "J",
    item: [

      {
        "name": "Jackson",
        "key": "J"
      },
      {
        "name": "Jefferson ",
        "key": "J"
      }
    
    ]
  }, {
    title: "K",
    item: [
      {
        "name": "Kansas City",
        "key": "K"

      }
    ]
  }, {

    title: "L",
    item:[
      {
        "name": "Lansing",
        "key": "L"
      },
      {
        "name": "Lincoln",
        "key": "L"
      },
      {
        "name": "Little Rock",
        "key": "L"
      },
      {
        "name": "Los Angeles",
        "key": "L"
      }
    ]
  }, {

    title: "M",
    item: [
      {
        "name": "Madison",
        "key": "M"
      }
      ,
      {
        "name": "Memphis",
        "key": "M"
      }
      ,
      {
        "name": "Miami",
        "key": "M"
      }
      ,
      {
        "name": "Minneapolis",
        "key": "M"
      }
      ,
      {
        "name": "Montgomery",
        "key": "M"
      }
      ,
      {
        "name": "Montpelier",
        "key": "M"
      }
      ,
      {
        "name": "Morristown",
        "key": "M"
      }
    ]
  }, {
    title: "N",
    item: [

      {
        "name": "Nashville",
        "key": "N"
      },
      {
        "name": "New Orleans",
        "key": "N"
      },
      {
        "name": "New York",
        "key": "N"
      }
    ]
  }, {
    title: "P",
    item: [

      {
        "name": "Philadelphia",
        "key": "P"
      }
      ,
      {
        "name": "Phoenix",
        "key": "P"
      }
      ,
      {
        "name": "Portland",
        "key": "P"
      }
      ,
      {
        "name": "Providence",
        "key": "P"
      }
  

    ]
  }, 
   {

    title: "R",
    item: [
      {
        "name": "Raleigh",
        "key": "R"
      },
      {
        "name": "Richmond",
        "key": "R"
      }
    ]
  }, {

    title: "S",
    item:[
      {
        "name": "Sacramento",
        "key": "S"
      },
      {
        "name": "Salem",
        "key": "S"
      },
      {
        "name": "Salt Lake City",
        "key": "S"
      },
      {
        "name": "San Francisco",
        "key": "S"
      },
      {
        "name": "Santa Fe",
        "key": "S"
      },
      {
        "name": "Seattle",
        "key": "S"
      },
      {
        "name": "Springfield",
        "key": "S"
      }
      ,
      {
        "name": "St Louis",
        "key": "S"
      }

      ,
      {
        "name": "St Paul",
        "key": "S"
      }
    ]
  }, {
    title: "T",
    item: [

      {
        "name": "Tallahassee",
        "key": "T"
      },
      {
        "name": "Topeka",
        "key": "T"
      },
      {
        "name": "Trenton",
        "key": "T"
      }
    ]
  }
]

module.exports = city;